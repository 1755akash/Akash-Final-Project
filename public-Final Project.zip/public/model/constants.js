export const DEV = true;

export const COLLECTION_NAMES = {
    PRODUCT: 'products',
    PURCHASE_HISTORY: 'purchase_history',
    ACCOUNT_INFO: 'account_info',
    PRODUCT_COMMENTS:'product_comment',
    PRODUCT_RATING:'product_rating',
    PRODUCT_WISHLIST:'product_wishlist',
}

export const STORAGE_FOLDER_NAMES = {
    PROFILE_PHOTOS: 'profile_photos/',
}